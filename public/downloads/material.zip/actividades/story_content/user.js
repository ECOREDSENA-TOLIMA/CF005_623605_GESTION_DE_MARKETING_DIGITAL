function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6XPiDr1CSgm":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

